import shopp.bi.*;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Shop {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/nishtha";
        String user = "root";
        String password = "qwer";
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the database.");
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database.");
            e.printStackTrace();
        }
        Scanner scanner = new Scanner(System.in);
        boolean isRunning = true;
        while (isRunning) {
            {
                System.out.println("Welcome to the Online Shop!");
                System.out.println("1. View Products");
                System.out.println("2. Add to Cart");
                System.out.println("3. View Cart");
                System.out.println("4. Checkout");
                System.out.println("5. Exit");
                System.out.print("Please enter your choice: ");
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:

                        String sql = "SELECT * FROM productss";

                        try {

                            PreparedStatement statement = connection.prepareStatement(sql);

                            ResultSet resultSet = statement.executeQuery();

                            while (resultSet.next()) {
                                int productId = resultSet.getInt("product_id");
                                String productName = resultSet.getString("product_name");
                                double productPrice = resultSet.getDouble("product_price");
                                System.out.println("Product ID: " + productId);
                                System.out.println("Product Name: " + productName);
                                System.out.println("Product Price: " + productPrice);
                            }

                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                        break;
                    case 2:
                        System.out.print("Enter the Product ID to add to the cart: ");
                        int productIdToAdd = scanner.nextInt();

                        String checkProductSql = "SELECT * FROM productss WHERE product_id = ?";
                        try {
                            PreparedStatement checkProductStatement = connection.prepareStatement(checkProductSql);
                            checkProductStatement.setInt(1, productIdToAdd);
                            ResultSet productResultSet = checkProductStatement.executeQuery();

                            if (productResultSet.next()) {
                                // Product exists, add it to the cart
                                String addToCartSql = "INSERT INTO cart (product_id, product_name, product_price) " +
                                        "SELECT product_id, product_name, product_price FROM productss WHERE product_id = ?";

                                try {
                                    PreparedStatement addToCartStatement = connection.prepareStatement(addToCartSql);
                                    addToCartStatement.setInt(1, productIdToAdd);
                                    int rowsAffected = addToCartStatement.executeUpdate();

                                    if (rowsAffected > 0) {
                                        System.out.println("Product added to the cart successfully.");
                                    } else {
                                        System.out.println("Failed to add the product to the cart. Please try again.");
                                    }
                                } catch (SQLException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                System.out.println("Product with ID " + productIdToAdd + " does not exist.");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 3:
                        // View Cart
                        String viewCartSql = "SELECT * FROM cart";

                        try {
                            PreparedStatement viewCartStatement = connection.prepareStatement(viewCartSql);
                            ResultSet cartResultSet = viewCartStatement.executeQuery();

                            System.out.println("Cart Contents:");

                            // Check if there are rows in the result set
                            if (cartResultSet.next()) {
                                do {
                                    int productId = cartResultSet.getInt("product_id");
                                    String productName = cartResultSet.getString("product_name");
                                    double productPrice = cartResultSet.getDouble("product_price");

                                    System.out.println("Product ID: " + productId);
                                    System.out.println("Product Name: " + productName);
                                    System.out.println("Product Price: " + productPrice);
                                    System.out.println("---------------------------");
                                } while (cartResultSet.next());
                            } else {
                                System.out.println("Cart is empty.");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                        break;
                    case 4:
                        // Checkout - Calculate Total Amount
                        String totalAmountSql = "SELECT SUM(product_price) AS total FROM cart";

                        try {
                            PreparedStatement totalAmountStatement = connection.prepareStatement(totalAmountSql);
                            ResultSet totalAmountResultSet = totalAmountStatement.executeQuery();

                            if (totalAmountResultSet.next()) {
                                double totalAmount = totalAmountResultSet.getDouble("total");
                                System.out.println("Total Amount in the Cart: " + totalAmount);

                                if (totalAmount > 0) {
                                    System.out.println(
                                            "Thank you for your purchase! Your products will be delivered soon.");
                                } else {
                                    System.out.println("Cart is empty. No purchase made.");
                                }
                            } else {
                                System.out.println("Error calculating total amount.");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                        break;

                    case 5:
                        // Clear Cart and Start Over
                        String clearCartSql = "DELETE FROM cart";

                        try {
                            PreparedStatement clearCartStatement = connection.prepareStatement(clearCartSql);
                            int rowsAffected = clearCartStatement.executeUpdate();

                            if (rowsAffected > 0) {
                                System.out.println("Cart cleared successfully. Starting over.");
                            } else {
                                System.out.println("Failed to clear the cart. Please try again.");
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                        // You might also want to reset any other state or variables as needed
                        // For example, if there are any user-specific details or selections, reset
                        // them.

                        break;

                }
            }
        }
        scanner.close();
    }
}