package shopp;

import shopp.bi.customer;
import java.util.ArrayList;

public class admin {
    private String adminId;
    private String adminName;
    private String adminEmail;
    private int adminPhone;
    private ArrayList<customer> registeredCustomers;

    public admin(String adminId, String adminName, String adminEmail, int adminPhone) {
        this.adminId = adminId;
        this.adminName = adminName;
        this.adminEmail = adminEmail;
        this.adminPhone = adminPhone;
        this.registeredCustomers = new ArrayList<>();
    }

    public String getadminId() {
        return adminId;
    }

    public String getadminName() {
        return adminName;
    }

    public String getadminEmail() {
        return adminEmail;
    }

    public int adminPhone() {
        return adminPhone;
    }

    public void addcustomer(customer customer) {
        registeredCustomers.add(customer);
    }

    public void removecustomer(customer customer) {
        registeredCustomers.remove(customer);
    }

    public void editCustomerProfile(customer customer, String newEmail, int newPhone) {

        for (customer c : registeredCustomers) {
            if (c.getCustomerId() == customer.getCustomerId()) {
                c.setCustomerEmail(newEmail);
                c.setCustomerPhone(newPhone);
                break;
            }
        }
    }

    public void viewRegisteredCustomers() {
        System.out.println("Registered Customers:");
        for (customer c : registeredCustomers) {
            System.out.println("Customer ID: " + c.getCustomerId());
            System.out.println("Customer Name: " + c.getCustomerName());
            System.out.println("Customer Email: " + c.getCustomerEmail());
            System.out.println("Customer Phone: " + c.getCustomerPhone());
            System.out.println("---------------------------");
        }
    }
}
