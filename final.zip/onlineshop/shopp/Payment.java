package shopp;

import java.util.ArrayList;
import shopp.bi.customer;

public class Payment {
    private customer customer;
    private ArrayList<bill> bills;
    private String cardNumber;
    private double balance;

    public Payment(customer customer) {
        this.customer = customer;
        this.bills = new ArrayList<>();
        this.cardNumber = "";
        this.balance = 0.0;
    }

    public void addBill(bill bill) {
        bills.add(bill);
    }

    public void displayBills() {
        if (bills.isEmpty()) {
            System.out.println("No bills to display.");
        } else {
            System.out.println("Bills for " + customer.getCustomerId() + ":");
            for (bill b : bills) {
                b.billsinfo();
            }
        }
    }

    public void payBill(bill bill) {
        if (balance >= bill.getTotalAmount()) {
            balance -= bill.getTotalAmount();
            System.out.println("Bill paid successfully.");
        } else {
            System.out.println("Insufficient balance to pay the bill.");
        }
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }
}
