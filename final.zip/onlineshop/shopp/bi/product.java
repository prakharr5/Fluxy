package shopp.bi;

public class product {
    private String productId;
    private String productName;
    private double productPrice;
    private String Category;

    public product(String productId, String productName, double productPrice,String Category) {
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.Category= Category;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public String getCategory() {
        return Category;
    }
}
