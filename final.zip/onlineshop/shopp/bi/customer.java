package shopp.bi;

public class customer {
    private String customerid;
    private String customerName;
    private String customerEmail;
    private int customerPhone;

    public customer(String customerid, String customerName,String customerEmail,int customerPhone ){
        this.customerid= customerid;
        this.customerName= customerName;
        this.customerEmail=customerEmail;
        this.customerPhone=customerPhone;
    }
    public String getCustomerId(){
        return customerid;
    }

    public String getCustomerName(){
        return customerName;
    }
    public String getCustomerEmail(){
        return customerEmail;
    }
    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public int getCustomerPhone(){
        return customerPhone;
    }
    public void setCustomerPhone(int customerPhone) {
        this.customerPhone = customerPhone;
    }
}
