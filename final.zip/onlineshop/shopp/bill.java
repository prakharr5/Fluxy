package shopp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import shopp.bi.product;
import shopp.bi.customer;

public class bill {
    private int billId;
    private ArrayList<product> purchasedProducts = new ArrayList<>();
    private double totalAmount;
    private customer customer;

    public bill(int billId,ArrayList<product> purchasedProducts,double totalAmount,customer customer){
      this.billId=billId;
    this.purchasedProducts= purchasedProducts;
    this.totalAmount= totalAmount;
    this.customer=customer;  
    }
    public void addPurchasedProduct(product product){
        purchasedProducts.add(product);
    }
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public void billsinfo() {
        System.out.println("Bill ID: "+ billId);
        System.out.println("Total Amount: " + totalAmount);
        System.out.println("Purchased Products:");
        for (product p : purchasedProducts) {
            System.out.println("Product ID: " + p.getProductId());
            System.out.println("Product Name: " + p.getProductName());
            System.out.println("Product Price: " + p.getProductPrice());
            System.out.println("Product Category: " + p.getCategory());
            System.out.println("---------------------------");
        }
    }
}



    