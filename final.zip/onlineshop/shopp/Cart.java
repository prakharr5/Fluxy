package shopp;
import java.util.ArrayList;
import shopp.bi.product;
public class Cart {
    private ArrayList<product> cartItems;

    public Cart() {
        cartItems = new ArrayList<>();
    }

    public void addToCart(product product) {
        cartItems.add(product);
    }

    public void viewCart() {
        if (cartItems.isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
            System.out.println("Your cart contains:");
            for (product p : cartItems) {
                System.out.println("Product ID: " + p.getProductId());
                System.out.println("Product Name: " + p.getProductName());
                System.out.println("Product Price: " + p.getProductPrice());
                System.out.println("Product Quantity: " + p.getCategory());
                System.out.println("---------------------------");
            }
        }
    }

    public void removeProductFromCart(product product) {
        cartItems.remove(product);
    }

    public void cancelCart() {
        cartItems.clear();
        System.out.println("Your cart has been canceled.");
    }
}
